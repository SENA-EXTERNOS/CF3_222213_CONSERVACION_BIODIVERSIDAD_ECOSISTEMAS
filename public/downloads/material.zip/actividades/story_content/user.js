function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6i5rahEjRmr":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

